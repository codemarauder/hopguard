MENU_ARRAY = [
				{name:"Dashboard", submenu: ["Overview","Item 01","Item 02","Item 03"],	subheading: "An Overview of network status"},
				{name: "View Reports",submenu: ["User Activity","Item 11","Item 12","Item 13"],subheading: "In Depth Reports of all kinds"},
				{name: "Enforce Policies",submenu: ["Manage Categories","Manage TimeSlots","URL Filtering","Web 2.0 Filtering"], subheading: "Configure Network Policies here"}
	]
MENU_ARRAY_ADMIN_OBJECT = {name:"Administer",submenu: ["General Info","Manage Locations","Manage Users","Manage Subscriptions"],subheading: "Manage Organisation specific settings"}
URL_LOGGED_USER = "/admin/user/loggedin"
URL_USERS_LIST = "/admin/user/list"
URL_GROUPS_LIST = "/admin/group/list"
URL_CATEGORY_LIST = "/admin/category/list"
URL_LOCATION_LIST = "/admin/location/list"
URL_POLICY_LIST = "/admin/policy/list"
URL_CUSTOMER_DETAILS = "/admin/customer/details"
URL_CATEGORY_DETAILS = "/admin/category/get_details"

