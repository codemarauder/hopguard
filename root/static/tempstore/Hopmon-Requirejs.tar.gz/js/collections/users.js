define([
  'jQuery',
  'Underscore',
  'Backbone',
  'models/user'
], function($, _, Backbone, userModel){
  var usersCollection = Backbone.Collection.extend({
    model: userModel,
		url: ""
  });
  return new usersCollection;
});
