define([
  'jQuery',
  'Underscore',
  'Backbone',
  'models/policy'
], function($, _, Backbone, policyModel){
  var policiesCollection = Backbone.Collection.extend({
    model: policyModel,
		url: URL_POLICY_LIST
  });

  return new policiesCollection;
});
