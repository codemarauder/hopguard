define([
  'jQuery',
  'Underscore',
  'Backbone',
  'models/category'
], function($, _, Backbone, categoryModel){
  var categoriesCollection = Backbone.Collection.extend({
    model: categoryModel,
		url: URL_CATEGORY_LIST,
  });

  return new categoriesCollection;
});
