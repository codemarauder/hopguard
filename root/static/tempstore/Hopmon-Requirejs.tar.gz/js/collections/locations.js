define([
  'jQuery',
  'Underscore',
  'Backbone',
  'models/location'
], function($, _, Backbone, locationModel){
  var locationsCollection = Backbone.Collection.extend({
    model: locationModel,
		url: URL_LOCATION_LIST
  });

  return new locationsCollection;
});
