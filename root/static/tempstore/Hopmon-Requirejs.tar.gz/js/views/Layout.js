// Filename: views/layout
define([ 
  'jQuery',
  'Underscore',
  'Backbone',
  'Marionette',
  'text!templates/layout.handlebars'

], function($, _, Backbone, Marionette, layoutTemplate){
  return Backbone.Marionette.Layout.extend({
		template : layoutTemplate,
		regions: {
		  menu: "#navigator",
		  submenu: "#subnav",
		  content: "#content"
		}
  });
});
