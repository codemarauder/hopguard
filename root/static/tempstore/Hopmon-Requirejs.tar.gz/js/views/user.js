// Filename: views/home/user
define([
  'jquery',
  'underscore',
  'backbone',
  // Pull in the Collection module from above
  'collections/users',
  'text!templates/home/employee.handlebars'

], function($, _, Backbone, usersCollection, userTemplate){
  var employeeView = Backbone.View.extend({
    el: $("#page"),
    initialize: function(){
      this.collection = usersCollection;
      this.collection.fetch();
    },
    render: function(){
      var data = {
        users: this.collection.models,
        _: _
      };
      var compiledTemplate = _.template( userTemplate, data );
      $("#employee").html( compiledTemplate );
    }
  });
  return new employeeView;
});
