// Filename: views/layout
define([
  'jQuery',
  'Underscore',
  'Backbone',
	'Marionette',
  'text!templates/subnav.handlebars'

], function($, _, Backbone, Marionette,subnavTemplate){
  var Subnav = Backbone.Marionette.ItemView.extend({
		template : subnavTemplate,
  });

  var initialize = function(){
		//Create a Router to track application states
    var subnav = new Subnav;
		//Create the initial layout
  };
  return {
    initialize: initialize
  };
});
