// Filename: views/navigator
define([
  'jQuery',
  'Underscore',
  'Backbone',
	'Marionette',
  'models/currentuser',
  'text!templates/navigator.handlebars'

], function($, _, Backbone, Marionette,currentUserModel, navigatorTemplate){
  return Backbone.Marionette.ItemView.extend({
		template : "<div>Hello Alligator<div>",
		model : currentUserModel
  });
/*  var initialize = function(){
		//Create a Router to track application states
    var navigator = new Navigator;
		//Create the initial layout
  };
  return {
    initialize: initialize
  };*/
});
