define([
  'Underscore',
  'Backbone'
], function(_, Backbone) {
  var userModel = Backbone.Model.extend({
		urlRoot: "/admin/user/list"
  });
  return userModel;
});
