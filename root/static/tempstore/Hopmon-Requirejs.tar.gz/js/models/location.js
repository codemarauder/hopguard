define([
  'Underscore',
  'Backbone'
], function(_, Backbone,Model) {
  var locationModel = Backbone.Model.extend({
		urlRoot: URL_LOCATION_LIST
  });
  return locationModel;
});
