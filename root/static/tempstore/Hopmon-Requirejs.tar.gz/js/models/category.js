define([
  'Underscore',
  'Backbone'
], function(_, Backbone) {
  var categoryModel = Backbone.Model.extend({
		urlRoot: URL_CATEGORY_LIST
  });
  return categoryModel;
});
