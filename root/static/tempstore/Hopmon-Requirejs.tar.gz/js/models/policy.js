define([
  'Underscore',
  'Backbone'
], function(_, Backbone) {
  var policyModel = Backbone.Model.extend({
		urlRoot: URL_POLICY_LIST
  });
  return policyModel;
});
