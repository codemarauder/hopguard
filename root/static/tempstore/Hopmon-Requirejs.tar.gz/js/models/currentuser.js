// Filename: models/currentuser
define([
  'Underscore',
  'Backbone',
	'models/loggeduser',
	'helpers/constants'
], function(_, Backbone,loggedUserModel,Constants) {
  var currentUser = loggedUserModel.extend({
		fullname : __super__.logged_user.fullname,
		email : __super__.logged_user.email,
		role : __super__.logged_user.roles[0],
		menuitems : Constants.MENU_ARRAY,
		currentMenu : "Dashboard",
		currentSubMenu : "Overview"
  });
  return currentUser;
});
