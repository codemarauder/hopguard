define([
  'Underscore',
  'Backbone'	
], function(_, Backbone) {
  return Backbone.Model.extend({
		initialize : function(){
			this.fetch();
		},
		urlRoot: "/admin/user/loggedin",
		logged_user:''
  });
});
