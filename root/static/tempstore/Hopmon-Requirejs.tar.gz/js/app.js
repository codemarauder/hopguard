define([
  'jQuery',
  'Underscore',
	'Backbone',
	'Marionette',
  'router'
//	'views/navigator',
//	'views/subnav'
], function($, _, Backbone, Marionette, Router){
  return {
		collections: {},
		models: {},
		helpers: {},
		views: {},
		pages: {},
		forms: {},
		router: {},
    initialize: function(){
			//Create the application container
			var Hopmon = new Backbone.Marionette.Application();
			Hopmon.addRegions({		  
				navigator: "#navigator",
				subnav: "#subnav",
				content: "#content"
			});

		  // Pass in our Router module and call it's initialize function
			Hopmon.addInitializer(function(options){
				try{
//						Hopmon.navigator.show(new NavigatorView());
//						Hopmon.subnav.show(new SubnavView());	
						  Router.initialize();
						console.log("Inside Hopmon Initializer");
				}
				catch(e){
					console.log("Caught error : " + e);
				}
			});	
			// Lets start the magic
			Hopmon.start();
			Backbone.history.start({pushState: true, root: "/ui/"});
		}
  };
});
