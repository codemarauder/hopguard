// Filename: main.js
require.config({
  paths: {
    jQuery: 'libs/jquery/jquery-min',
    Underscore: 'libs/underscore/underscore-min',
    Backbone: 'libs/backbone/backbone-min',
		Marionette: 'libs/backbone/backbone.marionette.min', 
		Handlebars: 'libs/handlebars/handlebars-1.0.0.beta.6', 
    templates: 'templates'
  }
});

require([
	// Load our app module and pass it to our definition function
	'jQuery',
	'Underscore',
	'Backbone',
	'Marionette',
	'app'
  // Some plugins have to be loaded in order due to their non AMD compliance
  // Because these scripts are not "modules" they do not pass any values to the definition function below
], function($, _, Backbone, Marionette, App){
	// Backbone.Marionette : Load Templates instead of inline scripts
	Backbone.Marionette.TemplateCache.prototype.loadTemplate = function(templateId) {
			// Marionette expects "templateId" to be the ID of a DOM element.
			// But with RequireJS, templateId is actually the full text of the template.
			var template = templateId;

			// Make sure we have a template before trying to compile it
			if (!template || template.length === 0){
			    var msg = "Could not find template: '" + templateId + "'";
			    var err = new Error(msg);
			    err.name = "NoTemplateError";
			    throw err;
			}

			return template;
	};
	// Backbone.Marionette : Use handlebars templates
	Backbone.Marionette.TemplateCache.prototype.compileTemplate = function(rawTemplate) {
	    return Handlebars.compile(rawTemplate);
	};

  // The "app" dependency is passed in as "App"
  // Again, the other dependencies passed in are not "AMD" therefore don't pass a parameter to this function
  App.initialize();

});


