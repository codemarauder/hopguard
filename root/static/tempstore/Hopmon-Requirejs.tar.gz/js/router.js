// Filename: router.js
define([
  'jQuery',
  'Underscore',
  'Backbone',
	'Marionette',
	'app',
  'controllers/hopcontroller'
], function($, _, Backbone, Marionette, app, hopcontroller){
  var HopRouter = Backbone.Marionette.AppRouter.extend({
    appRoutes: {
      // Define some URL routes
      ':menuitem': 'showMenuitem',
      ':menuitem/:submenuitem': 'showSubMenuitem',
			'*actions' : 'defaultAction'
    }
  });
  
	return {
		initialize: function(){
			console.log("Inside Router Initializer");
			//Create a Router to track application states
			app.hopRouter = new HopRouter({
				controller: hopcontroller
			});
		}
	};
});
