define([
  'jQuery',
  'Underscore',
  'Backbone'
//	'views/Layout'
], function($, _, Backbone){
		showMenuitem = function(menuitem){
			console.log("showMenuitem: " + menuitem);
		};
		showSubMenuitem = function(menuitem,submenuitem){
			console.log("showSubMenuitem: " + menuitem +'/'+submenuitem);
		};

	return hopController = {
		showMenuitem : showMenuitem,
		showSubMenuitem : showSubMenuitem,
		defaultAction : function(actions){
			console.log("DefaultAction of Hopcontroller");
			showMenuitem("Dashboard");
		},
		initialize : function(){
			//Create the default Layout
			//layout = new Layout();
		}
	};
});
